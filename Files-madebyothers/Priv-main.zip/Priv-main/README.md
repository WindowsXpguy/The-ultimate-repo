# PRIV
This is a repository filled with school proxy/game websites and chromeOS hacks to bypass school web filtering.

<br/>

**Need help? Ask for help <a href="https://discord.com/users/1341610845733650527">here</a>!**

<br/>

**Website (Auto Updated)**
https://agguiopz.github.io/Priv/

<br/>

![sob](https://files.catbox.moe/9vc62a.png)

# Collaborators
<br/>
<img src="https://avatars.githubusercontent.com/u/135869371?v=4|width=10px" alt="kg" width="100" height = "100"/>


# TABLE OF CONTENTS


- [PRIV](#priv)
  * [Classlink Login **(History Flooder)**](#classlink-login)
  * [Guest Mode **(Unrestricted Browsing)**](#guest-mode)
  * [SimplyVPN **(Unblock Network Blocked Sites)**](#simplyvpn)
  * [Corkey **(Corrupt Extensions)**](#corkey)
  * [ExtHang3r **(Freeze Extensions)**](#exthang3r)
  * [RigTools **(Disable Extensions**](#rigtools)
  * [Dextensify **(Freeze Extensions)**](#dextensify)
  * [LTMEAT **(Freeze Extensions)**](#ltmeat)
  * [Corkey **(Corrupt Extensions)**](#corkey)
  * [BlobWifi **(Disable Updates)**](#blobwifi)
  * [CauDNS **(Edit Server Names)**](#caudns)
  * [Chrome100 **(Revert Versions)**](#chrome100)
  * [Policy Password Tool **(WIFI Password Extractor)**](#policy-password-tool)
  * [Bypass Content Keeper **(Bypass Blocked Pages)**](#bypass-content-keeper)
  * [Extension Information **(View Allowed and Unblocked Extensions)**](#extension-information)

## Classlink Login

𝗖𝗹𝗮𝘀𝘀𝗹𝗶𝗻𝗸 𝗟𝗼𝗴𝗶𝗻 is an html file that allows you to 𝗳𝗹𝗼𝗼𝗱 𝘆𝗼𝘂𝗿 𝗵𝗶𝘀𝘁𝗼𝗿𝘆 𝘄𝗶𝘁𝗵 𝗖𝗹𝗮𝘀𝘀𝗹𝗶𝗻𝗸 𝗟𝗼𝗴𝗶𝗻 to hide uneducational websites from your browser history. This will cause your computer to lag during flooding since the HTML website is actively creating new url inputs.

Created by [me](https://github.com/Agguiopz)
<br/>

<img src="https://camo.githubusercontent.com/e2d3bb7cd21619f06382ad5cec3dac8d32587f6fd555eb643788871c2e0b85ef/68747470733a2f2f66696c65732e636174626f782e6d6f652f386f686b38322e706e67" data-canonical-src="https://camo.githubusercontent.com/e2d3bb7cd21619f06382ad5cec3dac8d32587f6fd555eb643788871c2e0b85ef/68747470733a2f2f66696c65732e636174626f782e6d6f652f386f686b38322e706e67" width="500" height="300" />
<br/>

### How do I use it?
1. Download the [HTML file](https://github.com/Agguiopz/Priv/blob/main/Classlink%20Login.html) and open it

2. Put in the username and password which are both ``history``

3. Put an integer greater than one

4. You are all set, you can keep this running.

### Data:text Version (don't recommend)

I do not recommend using this because it won't show the name
<br/>

<img src="https://camo.githubusercontent.com/3c42820d66e8bb5d4a578caf32a90b28e3255a7669f64f92aec2e5db7ac32bb8/68747470733a2f2f66696c65732e636174626f782e6d6f652f3776396375702e706e67" data-canonical-src="https://camo.githubusercontent.com/3c42820d66e8bb5d4a578caf32a90b28e3255a7669f64f92aec2e5db7ac32bb8/68747470733a2f2f66696c65732e636174626f782e6d6f652f3776396375702e706e67" width="500" height="300" />
<br/>

1. Copy the text from [here](https://github.com/Agguiopz/Priv/blob/main/Classlink)
3. Put it in your url bar in a new tab
4. Follow instructions from 2-4 from the HTML version

### How can I change the credentials and the name/history?
Just open up the html file source code then find what you want to rename and then download the html file

<br/>

[**🔼 Back to Top**](#priv)

## Guest Mode
Allows you to go in the **Guest Mode** View of Google giving you **unrestricted web browsing**.

**This is unpatched on versions 129-132 (patched on 133)**

</br>

![guest](https://github.com/user-attachments/assets/3aa53c7f-e9d5-4f2f-87e2-a8bc68110add)

Discovered by [elisay (.elisay)](https://discord.com/users/647929484628066323)

### Advantages of Guest Mode

- Unrestricted Web Browsing (this includes administrator blocked websites)
- No Extensions
- Inspect is unblocked
- Bookmarklets are unblocked. However you need to type or copy and paste it in the URL bar to execute the code. Or you can just use inspect to execute code
- History is not recorded
- You can use any Google account while on guest mode
- AI Overviews are unblocked
- No settings are managed including your schools private network
- Crosh is unblocked
- Chrome://flags is unblocked
- "My Files" are unblocked
- All of chromes built in URL's are unblocked

### Disadvantages of Guest Mode
- You can't download any extensions
- You can't use bookmarks
- You can't download apps from the playstore

### How do I use it?

**You will have to factory reset your chromebook so make sure you know your wifi password at home or at school and make sure you sync all of the files you want to save into your google drive or any file storage**
<br/>

**Must have acess to DNS server name configuration, if you don't then use rigtools.**
<br/>

1. Powerwash / Factory Reset (Stay in the Welcome To Your Chromebook! / Get Started Screen)

   Press **Esc** + **Refresh**![refresh](https://github.com/user-attachments/assets/11d83e38-ece5-4433-8acc-5d3b452e9245) + **Power**

   Press **CTRL+D** on the recovery/insert USB screen

   Press **Enter**

2. Connect to any Wi-Fi network you have access to and set all dns to 0.0.0.0

   Open your taskbar on the bottom and press the button on the far right (the time, wifi, and battery)

   Press Wi-FI and connect to your wifi

   Press your WI-FI network and scroll down to the **network section**

   Change to **Custom name servers** and change all of the boxes to **0.0.0.0**

3. Disconnect and go back to Wi-Fi
4. Click get started and click **Add other wifi network**
5. Type in anything and press connect
6. Connect back to original wifi. If the google loading screen pops up press **shift+alt+s**, click **power**![power](https://github.com/user-attachments/assets/5d03cbb1-9c6c-45ae-822c-648de734c3d5), then restart
7. If you see the **browse as guest** [hyperlink](https://website.com) url pop up on the left, click it
8. If it does not work you gotta do steps all over again or powerwash and do it again

**To use bookmarklets you need to paste in the javascript code into the url or use inspect**

**Optional:** To downgrade on guest mode iGo to wifi set all dns to **0.0.0.0** then set the first dns to **150.136.163.0**, now go to crosh (ctrl + alt + t) then type rollback,  press enter, then type y and press enter and it should downgrade.

### Further Reading

[About Guest Mode](https://support.google.com/chromebook/?p=chromebook_guest)

<br/>

[**🔼 Back to Top**](#priv)

### SimplyVPN
VPN Method to **unblock** all network blocked sites

![image](https://github.com/user-attachments/assets/544846ca-c694-48a2-90b6-4fa9d13bcea4)

<br/>

Discovered by [ash (ash._ash)](https://discord.com/users/1046443045924634655)

### How do I use it?

1. Go to settings and go to the **network** tab
2. Click add **connection** then click add **built in VPN**
3. Click **OpenVPN** and select **l2tp/ipsec** from the drop-down list
4. Go [here](https://m.ipspeed.info/freevpn_l2tpipsec.php?language=en) and scroll down and copy any IP address / host name
5. Put the IP address / host name into the hostname text box
6. Put anything as the VPN namep
7. In **password**, **preshared key** and **username** enter **vpn** (group name is optional)
8. Connect to the newly configured VPN

### Further Reading
[Main Website Page](https://m.ipspeed.info/index.php?language=en)

<br/>

[**🔼 Back to Top**](#priv)

## Corkey
This exploit allows you to **corrupt extensions** interrupting the sync process.
<br/>

![corrupt](https://github.com/user-attachments/assets/1665178f-dd59-46fe-91c1-fabebfa5e5b6)

<br/>

Discovered by [AkaButNice](https://github.com/Aka-but-nice), [Bypassi#7037](https://github.com/bypassiwastaken)
<br/>
Named by [Ashton Davies](https://github.com/AshtonDavies) & [Brandon421-ops](https://github.com/Brandon421-ops) (Their github page was deleted)

### How do I use it?

**You will have to factory reset your chromebook so make sure you know your wifi password at home or at school (I advise doing this at home) and make sure you sync all of the files you want to save into your google drive**
<br/>

**You must have acess to login without wifi (sign in as an existing user)**
<br/>

**If your organization does not allow you to sign in without a network, you should instead prevent internet access on your network.**
<br/>

**This requires precise timing and good reflexes**

1. Powerwash / Factory Reset

   Press **Esc** + **Refresh**![refresh](https://github.com/user-attachments/assets/11d83e38-ece5-4433-8acc-5d3b452e9245) + **Power**![power](https://github.com/user-attachments/assets/5d03cbb1-9c6c-45ae-822c-648de734c3d5)

   Press **CTRL+D** on the recovery/insert USB screen

   Press **Enter**

2. Sign in
3. Immediatly disconnect from your network
4. Press **Refresh**![refresh](https://github.com/user-attachments/assets/11d83e38-ece5-4433-8acc-5d3b452e9245) + **Power**![power](https://github.com/user-attachments/assets/5d03cbb1-9c6c-45ae-822c-648de734c3d5)
5. Navigate to the url <ins>chrome://extensions</ins>
6. Connect to your network
7. Wait for the extension that you want to corrupt automatically install
8. **Immediately** disconnect from your network and restart
9. Sign in again as an existing user with no wifi to ensure the extension was corrupted just like what the image showed

   The other extensions shouldn't install

**Slightly Bad Scenario:** If you don't see any extenison or any of the extensions installed then you are gonna have to **try again** (do steps 7 - 9 again) and maybe do step 8 a little later but not too late otherwise it will fully install

**Worse Case Scenario:** If the extension is installed but its not corrupted you are going to have to **do it all over again** this means factory resseting once again

**Best Case Scenario:** You did it!! Repair any extensions you want to fix and restart your chromebook and **log in with your wifi** on again to fix your files not being able to be opened for download

### Further Reading
[Website](https://ext-remover.net/detail/Corkey/)

<br/>

[**🔼 Back to Top**](#priv)

## ExtHang3r
𝗘𝘅𝘁𝗛𝗮𝗻𝗴𝟯𝗿 is an exploit that allows ChromeOS users to 𝗸𝗶𝗹𝗹 𝗺𝗮𝗻𝗮𝗴𝗲𝗱 𝗲𝘅𝘁𝗲𝗻𝘀𝗶𝗼𝗻𝘀 after the LTMEAT patch. It remains unpatched in all new ChromeOS versions as of November 2024.

Created by [Blobby](https://github.com/Blobby-Boi)

### How do I use it?
Download the <a href="https://github.com/Agguiopz/Priv/blob/main/Ext-Hang3r.html">HTML file</a> or <a href="https://github.com/Agguiopz/Priv/blob/main/Ext-Hang3r">copy the data: link and paste it into a new tab</a>

### Note
When you start hanging it will take longer than one minute and it will lag a ton since it is refreshing iframes, so I recommend closing all your other tabs before hanging. If you are using securly please use ``securly (old)`` to disable Securly for Chromebooks.

### Further Reading
[Original Repository](https://github.com/Blobby-Boi/ExtHang3r)

<br/>

[**🔼 Back to Top**](#priv)

## RigTools

**Executing code** in Developer Tools and extensions. Capable of utilizing many privileges.

Made by [FWSmasher](https://github.com/FWSmasher) [[MunyDev](https://github.com/MunyDev), [Fallenmoon8080](https://github.com/Fallenmoon8080), Entrpix], [appleflyer](https://github.com/appleflyer)

### How do I use it?
**This is patched in chromeOS 128**
**Must have access to ``devtools://devtools/``**

1. Open this link and just leave it there
```md
devtools://devtools/bundled/devtools_app.html
```
2. Open this link and press the Network tab on the top
```md
devtools://devtools/bundled/devtools_app.html?experiments=true&ws=rig.kxtz.dev/
```
3. Double-Click the box under name

![name](https://files.catbox.moe/1px66z.png)

4. Press any of the keys 1-9 or click extension-ID and find your extension-ID.

5. (extension id method) If you clicked extension-id paste in the extension ID and it should load a filesystem: page. You may have other extensions under it, you can disable those too.

6. (hardcoded keys method) If you clicked any of the keys and got sent to the page you can disable any of the following extensions. You can also scroll down to see other scripts and even put in your own scripts.

### Further Reading
[Website](https://rig.ccsd.store/)
<br/>
[Repository](https://github.com/MunyDev/rigtools-v2)
<br/>
[Discord](https://discord.gg/TGYyNPtCQH)
<br/>
[Source Code](https://raw.githubusercontent.com/FWSmasher/rigtools/refs/heads/main/index.mjs)

### Associated Links
[Titanium Network](https://docs.titaniumnetwork.org/kajigs/rigtools/)
<br/>
[SincereHam222](http://sincereham222.cc:8080/)

<br/>

[**🔼 Back to Top**](#priv)

## Dextensify

**Dextensify** is an exploit which lets you 𝗱𝗶𝘀𝗮𝗯𝗹𝗲 𝗺𝗼𝘀𝘁 𝗮𝗱𝗺𝗶𝗻-𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗲𝗱 𝗖𝗵𝗿𝗼𝗺𝗲 𝗲𝘅𝘁𝗲𝗻𝘀𝗶𝗼𝗻𝘀 from any webpage. It can be used from regular websites, HTML files, and data URLs.

Made by [ading2210](https://ading.dev/)
<br/>
Improved Version by [STPv22](https://github.com/STPv22)

### How do I use it?
1. <a href="https://github.com/Agguiopz/Priv/blob/main/Dextensify.html">Open up the HTML file</a> or <a href="https://github.com/Agguiopz/Priv/blob/main/Dextensify">Copy the data: link and paste it into a new tab</a>
2. Open up your settings page for your extension (if you are using securly use **Securly for Chromebooks**
3. If you are on Securly use **Freeze Securly (old)** to bypass blocked pages. The other extensions are fine since it's usually just one extension
4. Press ok then instantly switch back to your extension page and start spamming ``Allow access to file URLs``
5. While you are in a middle of a laggy state wait a few seconds then instantly press your url bar and go to any website or smth and close the dextensify page
6. Note that the extension may turn back on at random intervals which is why you must sometimes have to press ``Allow access to file URLs`` again every few minutes

### Further Reading
[How it Works](https://ading.dev/blog/posts/dextensify.html)

<br/>

[**🔼 Back to Top**](#priv)

## UNBLOCK3R
Unblocks websites by making urls too long and 𝗼𝘃𝗲𝗿𝗹𝗼𝗮𝗱𝗶𝗻𝗴 𝘀𝗲𝗿𝘃𝗲𝗿𝘀.

Made by [schoolexploitkid](https://github.com/schoolexploitkid)

### How do I use it?
<a href="https://github.com/Agguiopz/Priv/blob/main/bypasser.html">Open up the HTML file</a> or <a href="https://github.com/Agguiopz/Priv/blob/main/UNBLOCK3R">copy the data: link and paste it into a new tab</a> and follow instructions on-screen from there

### Why does it not work?
This does not work for most extensions that can support more letters but you are free to use the other given options in the website.

### Further Reading

[How it Works/Original Repository](https://github.com/schoolexploitkid/UNBLOCK3R)

<br/>

[**🔼 Back to Top**](#priv)

## LTMEAT
Alternative method of [LTMEAT](https://ext-remover.net/detail/LTMEAT/index.html) based on [Alternate Method #1](https://ltmeat.bypassi.com/alt/1.txt) that **hangs and refreshes extensions** naturally without debug URLs.

### How do i use it?
Visit https://ext-remover.net/detail/LTMEAT%20Flood/ and follow on-screen instructions from there.

### Further Reading
[Github Discussion](https://github.com/3kh0/ext-remover/discussions/671)

<br/>

[**🔼 Back to Top**](#priv)

## BlobWifi

**Blobwifi** is an exploit that allows Chromebook users to 𝗿𝗲𝗺𝗼𝘃𝗲 𝗮𝗹𝗹 𝗼𝗳 𝘁𝗵𝗲 𝗿𝗲𝘀𝘁𝗿𝗶𝗰𝘁𝗶𝗼𝗻𝘀 𝗳𝗿𝗼𝗺 𝗮 𝗺𝗮𝗻𝗮𝗴𝗲𝗱 𝗪𝗶-𝗙𝗶 𝗻𝗲𝘁𝘄𝗼𝗿𝗸. It works similarly to another exploit, CAUB. (stops updates)

Created by [Blobby](https://github.com/Blobby-Boi)

### How do I use it?
Download the <a href="https://github.com/Agguiopz/Priv/blob/main/blobwifi.html">HTML file</a> and follow on-screen intrusctions from there

### Further Reading
[How it works/Original repository](https://github.com/Blobby-Boi/Blobwifi)

<br/>

[**🔼 Back to Top**](#priv)

## CauDNS
𝗖𝗮𝘂𝗗𝗡𝗦 allows you to edit your wifi name servers to bypass extensions
Created by [Potato.](https://github.com/dragon731012)

### How do I use it?
Download the <a href="https://github.com/Agguiopz/Priv/blob/main/caudns.html">HTML file</a> or <a href="https://github.com/Agguiopz/Priv/blob/main/cauDNS">put the data: link into a new tab</a> and follow on-screen instructions from there 

### Note
You can change the name servers you want to set by clicking advanced on the top left. This may not work and just entirely make your wifi connected with no internet.

### Further Reading
[Original Repository](https://github.com/dragon731012/cauDNS)

[Source Code](https://raw.githubusercontent.com/dragon731012/cauDNS/main/main.js)

<br/>

[**🔼 Back to Top**](#priv)

## Chrome100

𝗖𝗵𝗿𝗼𝗺𝗲𝟭𝟬𝟬 allows you to revert to a previous version of chromeOS.
Due to the complexity and details of this please visit https://chrome100.dev/guide
Created by [e9x](https://github.com/e9x)

<br/>

[**🔼 Back to Top**](#priv)

## Policy Password Tool
Extracts WIFI Password
Created by [luphoria](https://luphoria.com/)

### How do I use it?

**Must have access to chrome://net-export and chrome://policy**

<br/>


Visit https://luphoria.com/netlog-policy-password-tool and follow on-screen instructions

### Further Reading
https://discord.gg/unblock

<br/>

[**🔼 Back to Top**](#priv)

## Bypass Content Keeper
Allows you to **open blocked websites** with very **simple steps**.
<br/>

Discovered By [paxtoboss12](https://discord.com/users/564582252936429570)

### How do I use it?
1. Update your chromebook to the newest version
2. Keep retrying to open a blocked website
3. On the 3rd/4th try it will just let you in

If this didn't work then sit and cry in a corner or use the other methods.

![alt](https://files.catbox.moe/0dnue4.png)

[**🔼 Back to Top**](#priv)

## Extension Information
Nothing much just a method on how to view your **allowed extensions** and **blocked extensions**
<br/>

### How do I use it?
1. Navigate to the url <ins>chrome://policy</ins>
2. Search for any policy named ``ExtensionAllowList`` or ``ExtensionBlockList`` (or just search extension and see what you can find in the policy list)
3. View the properties of any of the two

 You will see random letters which are actually the extension ids

4. Copy any extension id and put in the url address bar 
```md
https://chromewebstore.google.com/detail/extensionidhere
```

<br/>


[**🔼 Back to Top**](#priv)
